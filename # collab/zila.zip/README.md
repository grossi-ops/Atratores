# CatGT Paper — Zenodo Deposit Package
## Catalytic Generative Theory (CatGT): Part I of the GOMC Opus
## Central theorem: Helical Selectivity Principle (HSP)

**Author:** Pablo Nogueira Grossi
**ORCID:** [0009-0000-6496-2186](https://orcid.org/0009-0000-6496-2186)
**Affiliation:** G6 LLC, Newark, New Jersey, USA
**Date:** May 2026
**Zenodo series root:** [10.5281/zenodo.19117399](https://doi.org/10.5281/zenodo.19117399)
**AXLE repository:** [github.com/TOTOGT/AXLE](https://github.com/TOTOGT/AXLE)
**Book + membership:** [g6llc.gumroad.com](https://g6llc.gumroad.com) ($30)
**Private peer-review repo (TeX source):** grossi-ops.github.io/B3 (on request)

---

## Naming

| Acronym | Full name | Role |
|---------|-----------|------|
| **GTCT** | Generative Temporal Contact Theory | Overarching framework |
| **CatGT** | Catalytic Generative Theory | GTCT applied to heterogeneous catalysis |
| **HSP** | Helical Selectivity Principle | Theorem 1 of CatGT |

CatGT is a domain instantiation of GTCT. The operator pipeline G = U∘F∘K∘C
and the contact manifold X_cat are GTCT primitives; their catalytic
interpretation is the subject of this paper.

---

## What is in this deposit

| File | Description |
|------|-------------|
| `paper.tex` | Full bilingual LaTeX source (English + Portuguese BR) |
| `paper.pdf` | Compiled PDF — the primary deposit artifact |
| `CatGT_Main.lean` | Lean 4 formal verification of HSP + computational scaffold |
| `SORRY_AUDIT.md` | Honest accounting of every sorry / admit in the Lean file |
| `zenodo_metadata.json` | Zenodo upload metadata |
| `README.md` | This file |
| `index.html` | Interactive HTML version of the paper with dynamic figures |
| `workflow.html` | CatGT research workflow diagram |

---

## How to reproduce

### Compile the paper

```bash
# Requires LaTeX with babel (english + brazilian), mathpazo, mdframed, booktabs
pdflatex paper.tex
pdflatex paper.tex   # run twice for TOC
```

### Check the Lean 4 proofs

```bash
# Requires Lean 4 and Mathlib (pin to the version in lakefile.lean in AXLE)
lake build CatGT_Main
```

The file type-checks without errors. The three `admit` stubs
(`catgt_dm3_transport`, `ensemble_scaling`, `dnls_norm_conservation_ideal`)
are honest open obligations documented in `SORRY_AUDIT.md`.

**Lean status: 6 closed, 3 honest admits, 0 hidden sorries.**

---

## Summary

CatGT unifies four length scales of catalytic description under a single
generative operator pipeline G = U∘F∘K∘C acting on a contact 3-manifold X_cat.

**Central theorem — Helical Selectivity Principle (HSP):**
Only reaction pathways whose radial coordinate r ≤ r*(λ) = √(J/λ)
can reach the stable catalytic fixed point x* of G.
Zeolite shape-selectivity, metal ensemble effects (Pt–Sn), and macroscopic
pellet design (trilobe/tetralobe extrudates) emerge as corollaries.

**Falsifiable predictions:** 3 (see §4 of the paper)

---

## Relation to the GOMC Opus

| Part | Topic | Status |
|------|-------|--------|
| **I (this paper)** | CatGT skeleton — HSP, Lean 4, predictions | Submitted |
| II | Numerical DNLS simulation — finite-size scaling | In preparation |
| III | Industrial case studies — FCC zeolite, Pt–Sn, BASF Quattro | Planned |
| IV | Photocatalysis extension — solar-to-fuel | Planned |

The broader GOMC framework includes the Coherence Bridge across seven
domains. See the Zenodo series root for all deposits.

---

## Citation

```bibtex
@misc{grossi2026catgt,
  author       = {Grossi, Pablo Nogueira},
  title        = {{Catalytic Generative Theory (CatGT):
                   Helical Selectivity Principle and Unified Framework
                   for Clean Energy Catalysis — Part I of the GOMC Opus}},
  month        = may,
  year         = 2026,
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.XXXXXXX},
  url          = {https://doi.org/10.5281/zenodo.XXXXXXX}
}
```

*(Replace XXXXXXX with the DOI assigned by Zenodo after upload.)*

---

## License

Paper text and LaTeX source: **CC BY 4.0**
Lean 4 code: **Apache 2.0**

---

## Contact

Pablo Nogueira Grossi · pgrossi888@outlook.com · pg6llc@gmail.com
G6 LLC · 90 Tiffany Blvd · Newark, NJ 07104
