# SORRY_AUDIT.md — CatGT_Main.lean
## Catalytic Generative Theory (CatGT), Part I of the GOMC Opus
## Central theorem: Helical Selectivity Principle (HSP)

**Date:** May 2026 | **Author:** Pablo Nogueira Grossi | **AXLE:** github.com/TOTOGT/AXLE

> **Naming note:** CatGT (Catalytic Generative Theory) is the catalysis
> instantiation of the overarching GTCT (Generative Temporal Contact Theory).
> The operator pipeline G = U∘F∘K∘C and the contact manifold X_cat are
> GTCT primitives applied to heterogeneous catalysis. HSP (Helical Selectivity
> Principle) is the central theorem of CatGT.

---

## Closed theorems (sorry-free)

| Theorem | Statement | Method |
|---------|-----------|--------|
| `ipr_between_zero_and_one` | IPR ∈ (0,1] for any nonzero ψ | Cauchy-Schwarz / Finset.sum inequalities |
| `helical_selectivity` ← **HSP** | r_state ≤ r*(λ) when r² ≤ J/λ | Real.sqrt_le_sqrt + algebraic bound |
| `criticalRadius_pos` | r*(λ) > 0 | div_pos + sqrt_pos_of_pos |
| `criticalRadius_antitone` | r* decreases as λ increases | sqrt_le_sqrt + div monotonicity |
| `selectivityFactor_eq` | σ = 1 − J/(λ·r_pore²) | ring + Real.sq_sqrt |
| `reeb_orbit_is_integral` | α(R) = 1 along Reeb orbit | ring |

**Total closed: 6**

---

## Honest admits / open obligations

| Theorem | Reason open | Path to closing |
|---------|-------------|-----------------|
| `catgt_dm3_transport` | Requires Mathlib support for Riemannian volume forms and convex shape optimisation | Await `Analysis.Manifold.VolumeForm`; target CatGT Part II |
| `ensemble_scaling` | Full proof requires a formal model of bimetallic surface geometry (Pt–Sn lattice) | Numerical validation via in-situ XAS first (Part III), then formal model |
| `dnls_norm_conservation_ideal` | Structural note; continuous conservation law requires ODE existence theory | Lean ODE integration when Mathlib `ODE.Basic` matures |

**Total admits: 3 (all documented, none hidden)**

---

## Collatz policy

The Collatz Conjecture is **not claimed** anywhere in this file.
It is tracked separately in `AXLE/OPEN_QUESTIONS.md` as a conjectured
application of GTCT structural arguments — status: **open conjecture**.

---

## Terminology map

| Term | Meaning |
|------|---------|
| **GTCT** | Generative Temporal Contact Theory — the overarching framework |
| **CatGT** | Catalytic Generative Theory — GTCT applied to heterogeneous catalysis |
| **HSP** | Helical Selectivity Principle — Theorem 1 of CatGT |
| **G = U∘F∘K∘C** | The generative operator pipeline (GTCT primitive) |
| **X_cat** | The catalyst contact manifold (GTCT primitive, catalysis instance) |
| **r*(λ) = √(J/λ)** | The central invariant of CatGT / HSP |

---

## Version history

| Version | Date | Change |
|---------|------|--------|
| V1 | May 2026 | Initial deposit — 6 closed, 3 honest admits, GTCT naming |
| V2 | May 2026 | Renamed to CatGT / HSP; GTCT reserved for overarching theory |
